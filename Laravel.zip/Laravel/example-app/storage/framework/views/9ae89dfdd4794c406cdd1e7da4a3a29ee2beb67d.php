<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jadwal Php</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
</head>
<body>
<table class="table table-dark">
  <thead>
    <tr>
      <th scope="col">Tanggal</th>
      <th scope="col">Matkul</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">05-10-2023</th>
      <td>Pemprograman Web Framework</td>
    </tr>
  </tbody>
</table>
</body>
</html><?php /**PATH C:\Users\INSTIKI\Desktop\Laravel\example-app\resources\views/jadwal.blade.php ENDPATH**/ ?>